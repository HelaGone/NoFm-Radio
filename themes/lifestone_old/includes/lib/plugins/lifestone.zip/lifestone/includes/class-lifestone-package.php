<?php

/**
 * Class LifestonePackage
 */
class LifestonePackage
{

    /**
     * @var
     */
    protected $loader;

    /**
     * @var string
     */
    protected $plugin_slug;

    /**
     * @var string
     */
    protected $version;

    /**
     * LifestonePackage constructor.
     */
    public function __construct()
    {
        $this->plugin_slug = 'lifestone_packages';
        $this->version = '1.0';
        $this->load_dependencies();
    }

    /**
     *
     */
    public function load_dependencies()
    {

        // Load WordPress core pluggable file
        if (is_admin()) require_once(ABSPATH . 'wp-includes/pluggable.php');

        // Load file that includes all the metabox for the site
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/lifestone-metabox.php';

        // Load Share count file
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-lifestone-share-count.php';

        // Load file for About Us Widget
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'widgets/widget-lifestone-about-us.php';

        // Load file for Recent Posts Widget
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'widgets/widget-lifestone-recent-posts.php';

        // Load file for Slider Shortcode
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/lifestone-shortcodes.php';

        // Load file for Demo Data Install
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'radium-one-click-demo-install/init.php';

    }

    /**
     * @return string
     */
    public function get_version()
    {
        return $this->version;
    }
}