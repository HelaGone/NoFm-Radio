<?php

/**
 * Class LifestoneshareCount
 * @author Prajwal Shrestha
 * @since 1.0
 */
class LifestoneshareCount {

    /**
     * @var string
     */
    private $url,$timeout;

    /**
     * LifestoneshareCount constructor.
     * @param $url
     * @param int $timeout
     */
    public function __construct($url, $timeout=10) {

        $this->url=rawurlencode($url);
        $this->timeout=$timeout;
    }


    /**
     * @return int
     */
    public function lifestone_get_linkedin_count() {
        $json_string = $this->file_get_contents_curl("http://www.linkedin.com/countserv/count/share?url=$this->url&format=json");
        $json = json_decode($json_string, true);
        return isset($json['count'])?intval($json['count']):0;
    }

    /**
     * @return int
     */
    public function lifestone_get_fb_count() {
        $json_string = $this->file_get_contents_curl('http://api.facebook.com/restserver.php?method=links.getStats&format=json&urls='.$this->url);
        $json = json_decode($json_string, true);
        return isset($json[0]['total_count'])?intval($json[0]['total_count']):0;
    }

    /**
     * @return int
     */
    public function lifestone_get_plusones_count()  {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, "https://clients6.google.com/rpc");
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_POSTFIELDS, '[{"method":"pos.plusones.get","id":"p","params":{"nolog":true,"id":"'.rawurldecode($this->url).'","source":"widget","userId":"@viewer","groupId":"@self"},"jsonrpc":"2.0","key":"p","apiVersion":"v1"}]');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
        $curl_results = curl_exec ($curl);
        curl_close ($curl);
        $json = json_decode($curl_results, true);
        return isset($json[0]['result']['metadata']['globalCounts']['count'])?intval( $json[0]['result']['metadata']['globalCounts']['count'] ):0;
    }


    /**
     * @param $url
     * @return mixed
     */
    private function file_get_contents_curl($url){
        $ch=curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
        $cont = curl_exec($ch);
        if(curl_error($ch))
        {
            die(curl_error($ch));
        }
        return $cont;
    }

}