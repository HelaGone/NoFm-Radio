<?php

if(!defined('ABSPATH')) exit;

/**
 * Initialize the custom Meta Boxes.
 */
add_action( 'admin_init', 'lifestone_meta_boxes' );

/**
 * Meta Boxes demo code.
 *
 * You can find all the available option types in demo-theme-options.php.
 *
 * @return    void
 * @since     2.0
 */
function lifestone_meta_boxes() {

    /**
     * Meta box for Posts
     */

    $lifestone_post_meta_box = array(
        'id'          => 'lifestone_post_meta_box',
        'title'       => esc_html__( 'Post Options', 'lifestone' ),
        'pages'       => array( 'post' ),
        'context'     => 'normal',
        'priority'    => 'high',
        'fields'      => array(
            array(
                'id'          => 'lifestone_post_media_option',
                'label'       => esc_html__( 'Media', 'lifestone' ),
                'desc'        => esc_html__('Select the option to display the type of media in the blog and blog post single.', 'lifestone'),
                'type'        => 'select',
                'std'         => 'featured-image',
                'choices'     => array(
                    array(
                        'value'    =>  'featured-image',
                        'label'    => esc_html__('Featured Image', 'lifestone')
                    ),
                    array(
                        'value'     => 'gallery',
                        'label'     => esc_html__('Gallery', 'lifestone')
                    ),
                    array(
                        'value'     => 'video',
                        'label'     => esc_html__('Video', 'lifestone')
                    )
                )
            ),
            array(
                'id'        => 'lifestone_post_media_gallery',
                'label'     => esc_html__('Gallery', 'lifestone'),
                'type'      => 'gallery',
                'condition' => 'lifestone_post_media_option:is(gallery)'
            ),
            array(
                'id'        => 'lifestone_post_media_video_source_option',
                'label'     => esc_html__('Video Source', 'lifestone'),
                'type'      => 'video_src',
                'condition' => 'lifestone_post_media_option:is(video)',
                'type'      => 'select',
                'choices'   => array(
                    array(
                        'label' => esc_html__( 'Youtube', 'lifestone'),
                        'value' => 'youtube'
                    ),
                    array(
                        'label' => esc_html__('Vimeo', 'lifestone'),
                        'value' => 'vimeo'
                    )
                )
            ),
            array(
                'id'        => 'lifestone_post_media_video_source',
                'desc'      => esc_html__( 'Enter the URL of the youtube video', 'lifestone' ),
                'label'     => esc_html__('Video Source', 'lifestone'),
                'type'      => 'text',
                'condition' => 'lifestone_post_media_option:is(video)',
            )
        )

    );
    $lifestone_page_meta_box = array(
        'id'          => 'lifestone_page_meta_box',
        'title'       => esc_html__( 'Page Settings', 'lifestone' ),
        'desc'        => '',
        'pages'       => array( 'post', 'page' ),
        'context'     => 'normal',
        'priority'    => 'high',
        'fields'      => array(
            array(
                'label'       => esc_html__( 'Banner', 'lifestone' ),
                'id'          => 'lifestone_page_banner',
                'type'        => 'tab'
            ),
            array(
                'id'        => 'lifestone_page_banner_option',
                'label'     => esc_html__('Enable banner for the page.', 'lifestone'),
                'desc'      => '',
                'type'      => 'on-off',
                'std'       => 'off'
            ),
            array(
                'id'        => 'lifestone_page_banner_image',
                'label'     => esc_html__('Images', 'lifestone'),
                'desc'      => esc_html__('Upload Images for the banner.', 'lifestone'),
                'type'      => 'gallery',
                'condition' => 'lifestone_page_banner_option:is(on)'
            ),
            array(
                'id'        => 'lifestone_page_banner_heading',
                'label'     => esc_html__('Enter heading', 'lifestone'),
                'desc'      => esc_html__("Enter the heading for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                'type'      => 'text',
                'condition' => 'lifestone_page_banner_option:is(on)'
            ),
            array(
                'id'        => 'lifestone_page_banner_tagline',
                'label'     => esc_html__('Enter tagline', 'lifestone'),
                'desc'      => esc_html__("Enter the short description for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                'type'      => 'text',
                'condition' => 'lifestone_page_banner_option:is(on)'
            ),
            array(
                'id'        => 'lifestone_page_breadcrumb_option',
                'label'     => esc_html__('Display breadcrumb', 'lifestone'),
                'desc'      => '',
                'type'      => 'on-off',
                'std'       => 'off',
                'condition' => 'lifestone_page_banner_option:is(on)'
            ),
            array(
                'label'       => esc_html__( 'Sidebar', 'lifestone' ),
                'id'          => 'lifestone_page_sidebar',
                'type'        => 'tab'
            ),
            array(
                'id'        => 'lifestone_page_sidebar_option',
                'label'     => esc_html__('Enable Sidebar', 'lifestone'),
                'desc'      => '',
                'type'      => 'on-off',
                'std'       => 'off'
            ),
        )

    );

    /**
     * Register our meta boxes using the
     * ot_register_meta_box() function.
     */
    if ( function_exists( 'ot_register_meta_box' ) )
        ot_register_meta_box( $lifestone_post_meta_box );

    $post_id = (isset($_GET['post'])) ? $_GET['post'] : ((isset($_POST['post_ID'])) ? $_POST['post_ID'] : false);

    if ($post_id) {
        $post_template = get_post_meta($post_id, '_wp_page_template', true);

        if ($post_template == 'default') ot_register_meta_box($lifestone_page_meta_box);
    }

}