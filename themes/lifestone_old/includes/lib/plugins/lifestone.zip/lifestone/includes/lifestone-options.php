<?php

if(!function_exists('lifestone_theme_options')) {

    /**
     * Build the custom settings & update OptionTree.
     *
     * @return    void
     * @since     2.0
     */
    function lifestone_theme_options()
    {

        /* OptionTree is not loaded yet, or this is not an admin request */
        if (!function_exists('ot_settings_id') || !is_admin())
            return false;

        /**
         * Get a copy of the saved settings array.
         */
        $saved_settings = get_option(ot_settings_id(), array());

        /**
         * Custom settings array that will eventually be
         * passes to the OptionTree Settings API Class.
         */
        $custom_settings = array(
            'contextual_help' => array(
                'content' => array(
                    array(
                        'id' => 'option_types_help',
                        'title' => __('Option Types', 'lifestone'),
                        'content' => '<p>' . __('Help content goes here!', 'lifestone') . '</p>'
                    )
                ),
                'sidebar' => '<p>' . __('Sidebar content goes here!', 'lifestone') . '</p>'
            ),
            'sections' => array(
                array(
                    'id' => 'general',
                    'title' => esc_html__('General', 'lifestone')
                ),
                array(
                    'id' => 'blog',
                    'title' => esc_html__('Blog', 'lifestone')
                ),
                array(
                    'id' => 'archive',
                    'title' => esc_html__('Archive', 'lifestone')
                ),
                array(
                    'id' => 'single-page',
                    'title' => esc_html__('Blog Single Post', 'lifestone')
                ),
                array(
                    'id' => 'search',
                    'title' => esc_html__('Search', 'lifestone')
                ),
                array(
                    'id' => '404',
                    'title' => esc_html__('404', 'lifestone')
                ),
            ),
            'settings' => array(

                array(
                    'id' => 'lifestone_loader_option',
                    'label' => esc_html__('Enable Loader', 'lifestone'),
                    'desc' => sprintf(__('Displays the loader until the page fully loads when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'general'
                ),

                array(
                    'id' => 'lifestone_sidebar_search_form_option',
                    'label' => esc_html__('Enable Search Form', 'lifestone'),
                    'desc' => sprintf(__('Displays the search form in the navigation sidebar when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'general'
                ),

                array(
                    'id' => 'lifestone_social_media_option',
                    'label' => esc_html__('Enable Social Media Icons', 'lifestone'),
                    'desc' => sprintf(__('Displays the Social Media Icons in the navigation sidebar when set to %s.', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'general'
                ),
                array(
                    'id' => 'lifestone_social_profiles',
                    'label' => esc_html__('Social Profiles', 'lifestone'),
                    'desc' => '',
                    'type' => 'list-item',
                    'section' => 'general',
                    'settings' => array(
                        array(
                            'id' => 'lifestone_social_profile_type',
                            'label' => esc_html__('Social Profile', 'lifestone'),
                            'desc' => '',
                            'std' => '',
                            'type' => 'select',
                            'choices' => array(
                                array(
                                    'label' => esc_html__('Facebook', 'lifestone'),
                                    'value' => 'facebook'
                                ),
                                array(
                                    'label' => esc_html__('Twitter', 'lifestone'),
                                    'value' => 'twitter'
                                ),
                                array(
                                    'label' => esc_html__('Instagram', 'lifestone'),
                                    'value' => 'instagram-outline'
                                ),
                                array(
                                    'label' => esc_html__('Linkedin', 'lifestone'),
                                    'value' => 'linkedin-outline'
                                ),
                                array(
                                    'label' => esc_html__('Pinterest', 'lifestone'),
                                    'value' => 'pinterest'
                                ),
                                array(
                                    'label' => esc_html__('Google Plus', 'lifestone'),
                                    'value' => 'googleplus-outline'
                                ),
                                array(
                                    'label' => esc_html__('Youtube', 'lifestone'),
                                    'value' => 'youtube'
                                ),
                                array(
                                    'label' => esc_html__('Vimeo', 'lifestone'),
                                    'value' => 'vimeo'
                                ),
                                array(
                                    'label' => esc_html__('Yahoo', 'lifestone'),
                                    'value' => 'yahoo'
                                ),
                                array(
                                    'label' => esc_html__('Skype', 'lifestone'),
                                    'value' => 'skype'
                                ),
                                array(
                                    'label' => esc_html__('Github', 'lifestone'),
                                    'value' => 'github'
                                ),
                                array(
                                    'label' => esc_html__('Dribble', 'lifestone'),
                                    'value' => 'dribbble-outline'
                                ),
                                array(
                                    'label' => esc_html__('RSS', 'lifestone'),
                                    'value' => 'rss'
                                ),

                                array(
                                    'label' => esc_html__('Wordpress', 'lifestone'),
                                    'value' => 'wordpress'
                                ),
                                array(
                                    'label' => esc_html__('Snapchat', 'lifestone'),
                                    'value' => 'snapchat'
                                ),
                                array(
                                    'label' => esc_html__('Wordpress', 'lifestone'),
                                    'value' => 'wordpress'
                                ),
                                array(
                                    'label' => esc_html__('FourSquare', 'lifestone'),
                                    'value' => 'foursquare'
                                ),
                                array(
                                    'label' => esc_html__('Tumblr', 'lifestone'),
                                    'value' => 'tumblr'
                                ),
                                array(
                                    'label' => esc_html__('Reddit', 'lifestone'),
                                    'value' => 'reddit'
                                ),
                                array(
                                    'label' => esc_html__('Designer-News', 'lifestone'),
                                    'value' => 'designernews'
                                ),
                                array(
                                    'label' => esc_html__('Hacker-News', 'lifestone'),
                                    'value' => 'hackernews'
                                ),
                                array(
                                    'label' => esc_html__('Buffer', 'lifestone'),
                                    'value' => 'buffer'
                                )
                            )
                        ),
                        array(
                            'id' => 'lifestone_social_profile_url',
                            'label' => esc_html__('Social Profile URL', 'lifestone'),
                            'desc' => esc_html__('Enter the URL of the Social Media Profile', 'lifestone'),
                            'type' => 'text'
                        ),
                    ),
                    'condition' => 'lifestone_social_media_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_blog_sidebar_option',
                    'label' => esc_html__('Enable Sidebar.', 'lifestone'),
                    'desc' => sprintf(__('Displays the sidebar when set to %s for the assigned blog page in "Settings > Reading"', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'blog'
                ),
                // Archive Option
                array(
                    'id' => 'lifestone_archive_banner_option',
                    'label' => esc_html__('Enable banner', 'lifestone'),
                    'desc' => sprintf(__('Displays the banner when set to %s.', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'archive'
                ),
                array(
                    'id' => 'lifestone_archive_banner_image',
                    'label' => esc_html__('Images for the banner.', 'lifestone'),
                    'desc' => '',
                    'type' => 'gallery',
                    'section' => 'archive',
                    'condition' => 'lifestone_archive_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_archive_banner_heading',
                    'label' => esc_html__('Enter heading', 'lifestone'),
                    'desc' => esc_html__("Enter the heading for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => 'archive',
                    'condition' => 'lifestone_archive_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_archive_banner_tagline',
                    'label' => esc_html__('Enter tagline', 'lifestone'),
                    'desc' => esc_html__("Enter a short description for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => 'archive',
                    'condition' => 'lifestone_archive_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_archive_cat_image_option',
                    'label' => esc_html__('Enable Category Images', 'lifestone'),
                    'desc' => sprintf(__('Displays the Category Images as banner when set to %s.', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'archive',
                    'condition' => 'lifestone_archive_banner_option:is(off)'
                ),
                array(
                    'id' => 'lifestone_archive_cat_title_option',
                    'label' => esc_html__('Display title', 'lifestone'),
                    'desc' => sprintf(__('Displays the Title when set to %s.', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'archive',
                    'condition' => 'lifestone_archive_banner_option:is(off),lifestone_archive_cat_image_option:is(on)'
                ),
                //
                array(
                    'id' => 'lifestone_single_banner_option',
                    'label' => esc_html__('Enable banner', 'lifestone'),
                    'desc' => sprintf(__('Displays the banner when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'single-page'
                ),
                array(
                    'id' => 'lifestone_single_banner_image',
                    'label' => esc_html__('Image', 'lifestone'),
                    'desc' => esc_html__('Upload Image for the banner', 'lifestone'),
                    'type' => 'gallery',
                    'section' => 'single-page',
                    'condition' => 'lifestone_single_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_single_banner_heading',
                    'label' => esc_html__('Heading', 'lifestone'),
                    'desc' => esc_html__("Enter the heading for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => 'single-page',
                    'condition' => 'lifestone_single_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_single_banner_tagline',
                    'label' => esc_html__('Tagline', 'lifestone'),
                    'desc' => esc_html__("Enter the short description for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => 'single-page',
                    'condition' => 'lifestone_single_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_single_breadcrumb_option',
                    'label' => esc_html__('Enable Breadcrumb', 'lifestone'),
                    'desc' => sprintf(__('Displays the breadcrumb in the banner when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'single-page',
                    'std' => 'off',
                    'condition' => 'lifestone_single_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_single_sidebar_option',
                    'label' => esc_html__('Enable Sidebar', 'lifestone'),
                    'desc' => sprintf(__('Displays the sidebar when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'single-page',
                    'std' => 'off'
                ),
                array(
                    'id' => 'lifestone_single_post_share_option',
                    'label' => esc_html__('Enable Post Sharing', 'lifestone'),
                    'desc' => sprintf(__('Displays the post sharing icons when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'single-page',
                    'std' => 'off'
                ),
                array(
                    'id' => 'lifestone_single_post_share_facebook_option',
                    'label' => esc_html__('Enable Post Sharing in Facebook', 'lifestone'),
                    'desc' => sprintf(__('Displays the post sharing in Facebook platform when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'single-page',
                    'std' => 'off',
                    'condition' => 'lifestone_single_post_share_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_single_post_share_twitter_option',
                    'label' => esc_html__('Enable Post Sharing in Twitter', 'lifestone'),
                    'desc' => sprintf(__('Displays the post sharing in Twitter platform when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'single-page',
                    'std' => 'off',
                    'condition' => 'lifestone_single_post_share_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_single_post_share_google_option',
                    'label' => esc_html__('Enable Post Sharing in Google Plus', 'lifestone'),
                    'desc' => sprintf(__('Displays the post sharing in Google Plus platform when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'single-page',
                    'std' => 'off',
                    'condition' => 'lifestone_single_post_share_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_single_post_share_linkedin_option',
                    'label' => esc_html__('Enable Post Sharing in Linkedin', 'lifestone'),
                    'desc' => sprintf(__('Displays the post sharing in Linkedin when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'single-page',
                    'std' => 'off',
                    'condition' => 'lifestone_single_post_share_option:is(on)'
                ),
                // Search Page Option
                array(
                    'id' => 'lifestone_search_banner_option',
                    'label' => esc_html__('Enable banner', 'lifestone'),
                    'desc' => sprintf(__('Displays the banner when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'search'
                ),
                array(
                    'id' => 'lifestone_search_banner_image',
                    'label' => esc_html__('Image', 'lifestone'),
                    'desc' => esc_html__('Upload Images for the banner', 'lifestone'),
                    'type' => 'gallery',
                    'section' => 'search',
                    'condition' => 'lifestone_search_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_search_banner_heading',
                    'label' => esc_html__('Heading', 'lifestone'),
                    'desc' => esc_html__("Enter the heading for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => 'search',
                    'condition' => 'lifestone_search_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_search_banner_tagline',
                    'label' => esc_html__('Tagline', 'lifestone'),
                    'desc' => esc_html__("Enter the short description for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => 'search',
                    'condition' => 'lifestone_search_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_search_breadcrumb_option',
                    'label' => esc_html__('Enable breadcrumb', 'lifestone'),
                    'desc' => sprintf(__('Displays the breadcrumb in the banner when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => 'search',
                    'std' => 'off',
                    'condition' => 'lifestone_search_banner_option:is(on)'
                ),
                //
                array(
                    'id' => 'lifestone_404_banner_option',
                    'label' => esc_html__('Enable banner', 'lifestone'),
                    'desc' => sprintf(__('Displays the banner when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => '404'
                ),
                array(
                    'id' => 'lifestone_404_banner_image',
                    'label' => esc_html__('Image', 'lifestone'),
                    'desc' => esc_html__('Upload Image for the banner', 'lifestone'),
                    'type' => 'gallery',
                    'section' => '404',
                    'condition' => 'lifestone_404_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_404_banner_heading',
                    'label' => esc_html__('Heading', 'lifestone'),
                    'desc' => esc_html__("Enter the heading for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => '404',
                    'condition' => 'lifestone_404_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_404_banner_tagline',
                    'label' => esc_html__('Tagline', 'lifestone'),
                    'desc' => esc_html__("Enter the short description for the page. You can leave it empty if you don't want to display heading", "lifestone"),
                    'type' => 'text',
                    'section' => '404',
                    'condition' => 'lifestone_404_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_404_breadcrumb_option',
                    'label' => esc_html__('Enable breadcrumb', 'lifestone'),
                    'desc' => sprintf(__('Displays the breadcrumb in the banner when set to %s', 'lifestone'), '<code>on</code>'),
                    'type' => 'on-off',
                    'section' => '404',
                    'std' => 'off',
                    'condition' => 'lifestone_404_banner_option:is(on)'
                ),
                array(
                    'id' => 'lifestone_404_breadcrumb_content',
                    'label' => esc_html__('Content', 'lifestone'),
                    'desc' => esc_html__('Enter the content that you want to displays in the error page', 'lifestone'),
                    'type' => 'textarea',
                    'section' => '404',
                ),
            )
        );

        /* allow settings to be filtered before saving */
        $custom_settings = apply_filters(ot_settings_id() . '_args', $custom_settings);

        /* settings are not the same update the DB */
        if ($saved_settings !== $custom_settings) {
            update_option(ot_settings_id(), $custom_settings);
        }

        /* Lets OptionTree know the UI Builder is being overridden */
        global $ot_has_custom_theme_options;
        $ot_has_custom_theme_options = true;

    }
    /**
     * Initialize the custom Theme Options.
     */
    add_action( 'init', 'lifestone_theme_options' );
}