<?php
if(!function_exists('lifestone_backstretch_slider')) {
    /**
     * @param $atts
     */
    function lifestone_backstretch_slider($atts)
    {

        extract(shortcode_atts(array(
            'ids' => '',
        ), $atts, 'lifestone-backstretch-slider'));


        $output = '';

        if($ids){
            $ids = explode(',', $ids );

            foreach ($ids as $id) {
                $sliderImageUrl = wp_get_attachment_image_url($id, 'full');
                $output .=  $sliderImageUrl . ', ';

            }
            $output = trim($output, ', ');
        }


        wp_localize_script( 'lifestone-backstretch', 'lifestoneSliders',
            array(
                'sliderImages' => $output
            )
        );

        wp_enqueue_script('lifestone-backstretch');

    }

    add_shortcode('lifestone-backstretch-slider', 'lifestone_backstretch_slider');
}