<?php
/*
* Plugin Name: Lifestone Packages
* Description: Essential components for Lifestone Wordpress theme
* Author: Prajwal Shrestha
* Version: 1.0
* Author URI: https://np.linkedin.com/in/prajwalstha
*/

if ( ! defined( 'ABSPATH' ) ) {
    die;
}
if (is_admin()) require_once(ABSPATH . 'wp-includes/pluggable.php');

require_once plugin_dir_path( __FILE__ ) . 'includes/class-lifestone-package.php';


function run_lifestone_package()
{
    new LifestonePackage();
}

run_lifestone_package();

if(!function_exists('unregister_default_wp_widgets')) {

    function unregister_default_wp_widgets()
    {

        unregister_widget('WP_Widget_Recent_Posts');
    }

    add_action('widgets_init', 'unregister_default_wp_widgets', 1);
}