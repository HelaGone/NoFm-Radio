<?php if ( !defined('ABSPATH') ) die('-1');

class Widget_About_Us extends WP_Widget
{

    public function __construct()
    {
        parent::__construct(
            'widget-lifestone-about-us',
            esc_html__('About Us', 'lifestone'),
            array(
                'description' => esc_html__('About Us', 'lifestone'),
                'classname'  => 'about-widget'
            )
        );
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['image_uri'] = ( ! empty( $new_instance['image_uri'] ) ) ? strip_tags( $new_instance['image_uri'] ) : '';
        $instance['tagline'] = ( ! empty( $new_instance['tagline'] ) ) ? strip_tags( $new_instance['tagline'] ) : '';
        $instance['content'] = ( ! empty( $new_instance['content'] ) ) ? strip_tags( $new_instance['content'] ) : '';
        $instance['page_link'] = (!empty($new_instance['page_link']) ) ? strip_tags( $new_instance['page_link'] ): '';

        return $instance;
    }

    public function widget( $args, $instance )
    {
        $title = apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );

        if ( array_key_exists('before_widget', $args) ) echo $args['before_widget']; ?>

        <?php if(!empty($instance['image_uri'])){
            $imgUrl = aq_resize($instance['image_uri'], '436', '540', true, true, true);
        } ?>

        <?php if(!empty($imgUrl)) { ?>

            <div>

                <img src="<?php echo esc_url($imgUrl); ?>" alt="<?php echo get_bloginfo('name'); ?>">

            </div>

            <div class="about-widget-content">

                <div class="about-widget-inwrap">

                    <div class="about-widget-detail">

                         <?php if ( !empty($title) ) { ?>

                            <h4><?php echo esc_html($title);?></h4>

                         <?php } ?>

                        <span><?php echo esc_html($instance['tagline']); ?></span>

                        <div class="post-entry">

                            <p><?php echo esc_html($instance['content']); ?></p>

                        </div><!-- post-entry -->

                        <a href="<?php echo esc_url($instance['page_link']); ?>" target="_blank" class="readmore_btn"><?php echo esc_html__('Readmore', 'lifestone'); ?></a>
                    </div>
                </div>
            </div>

        <?php } ?>

        <?php if ( array_key_exists('after_widget', $args) )  echo $args['after_widget'];
    }


    public function form( $instance )
    {
        $title            = isset( $instance['title'])  ? $instance['title'] : '';
        $image_uri        = isset($instance['image_uri'])  ? esc_attr($instance['image_uri']) : '';
        $tagline          = isset($instance['tagline'])  ? esc_attr($instance['tagline']) : '';
        $content          = isset($instance['content'])  ? esc_attr($instance['content']) : '';
        $page_link        = isset($instance['page_link']) ? esc_attr($instance['page_link']) : '';


        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo esc_html__( 'Heading:', 'lifestone' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('tagline'); ?>"><?php echo esc_html__('Tagline:', 'lifestone'); ?></label><br />
            <input type="text" name="<?php echo $this->get_field_name('tagline'); ?>" id="<?php echo $this->get_field_id('tagline'); ?>" value="<?php echo esc_attr($tagline); ?>" class="widefat" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('content'); ?>"><?php echo esc_html__('Content:', 'lifestone'); ?></label><br />
            <textarea class="widefat" rows="10" cols="10" id="<?php echo $this->get_field_id('content'); ?>" name="<?php echo $this->get_field_name('content'); ?>"><?php echo esc_attr($content); ?></textarea>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'image_uri' ); ?>"><?php echo esc_html__( 'Image:', 'lifestone'); ?></label><br />
            <?php
            if ( $instance['image_uri'] != '' ) {
                echo '<img class="custom_media_image" src="' . $instance['image_uri'] . '" /><br />'; ?>
                <input type="hidden" class="widefat custom-img" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo esc_attr($image_uri); ?>" style="margin-top:5px;" />

            <?php } else {?>
                <input type="hidden" class="widefat custom-img" name="<?php echo $this->get_field_name('image_uri'); ?>" id="<?php echo $this->get_field_id('image_uri'); ?>" value="<?php echo esc_attr($image_uri); ?>" style="margin-top:5px;" />
            <?php } ?>
                <div class="alignright">
                    <input type="button" class="lifestone-upload-img button button-primary right" value="<?php echo esc_attr__('Upload', 'lifestone'); ?>" style="margin-top:5px;"/>
                </div>
            <br />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('page_link'); ?>"><?php echo esc_html__('Page URL', 'lifestone'); ?></label><br />
            <input type="text" name="<?php echo $this->get_field_name('page_link'); ?>" id="<?php echo $this->get_field_id('page_link'); ?>" value="<?php echo esc_url($page_link); ?>" class="widefat" />
        </p>

        <?php
    }
}
// end class

// init the widget
add_action( 'widgets_init', create_function('', 'return register_widget("Widget_About_Us");') );

function lifestone_widget_about_us_scripts()
{
    wp_enqueue_media();
    wp_enqueue_script('lifestone_about_js', get_template_directory_uri() .'/js/backend.js', array(), '1.1.0', true);
}
add_action('admin_enqueue_scripts', 'lifestone_widget_about_us_scripts');